import 'package:flutter/material.dart';

/// Koulè Freda Workspace
class FredaColors {
  FredaColors._();
  static const Color midnight = Color(0xFF061137);
  static const Color navy = Color(0xFF071653);
  static const Color deep = Color(0xFF173A9E);
  static const Color blue = Color(0xFF2B64E4);
  static const Color sky = Color(0xFF4A95F5);
  static const Color mist = Color(0xFFEEF3FD);
  static const Color slate = Color(0xFF5B6478);
  static const Color amber = Color(0xFFF5B83D);

  static const LinearGradient gradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [navy, deep, blue, sky],
    stops: [0.0, 0.42, 0.78, 1.0],
  );
}
